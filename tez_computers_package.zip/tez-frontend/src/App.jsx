import React from 'react';
export default function App(){ return (<div style={{padding:20,fontFamily:'Arial'}}><h1 style={{color:'#0b63d6'}}>Tez Computers</h1><p>Admin frontend skeleton. Connect to backend API to manage products, customers, and invoices.</p></div>); }
